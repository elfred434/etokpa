---
name: TOKPa v2
colors:
  surface: '#fff8f6'
  surface-dim: '#edd5cb'
  surface-bright: '#fff8f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fff1eb'
  surface-container: '#ffeae0'
  surface-container-high: '#fce3d9'
  surface-container-highest: '#f6ded3'
  on-surface: '#251913'
  on-surface-variant: '#584237'
  inverse-surface: '#3c2d26'
  inverse-on-surface: '#ffede6'
  outline: '#8c7164'
  outline-variant: '#e0c0b1'
  surface-tint: '#9d4300'
  primary: '#9d4300'
  on-primary: '#ffffff'
  primary-container: '#f97316'
  on-primary-container: '#582200'
  inverse-primary: '#ffb690'
  secondary: '#855300'
  on-secondary: '#ffffff'
  secondary-container: '#fea619'
  on-secondary-container: '#684000'
  tertiary: '#006398'
  on-tertiary: '#ffffff'
  tertiary-container: '#00a2f4'
  on-tertiary-container: '#003554'
  error: '#EF4444'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbca'
  primary-fixed-dim: '#ffb690'
  on-primary-fixed: '#341100'
  on-primary-fixed-variant: '#783200'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#cde5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d32'
  on-tertiary-fixed-variant: '#004b74'
  background: '#fff8f6'
  on-background: '#251913'
  surface-variant: '#f6ded3'
  primary-hover: '#EA580C'
  primary-dark: '#C2410C'
  primary-deep: '#7C2D12'
  primary-light: '#FED7AA'
  primary-tint: '#FFF7ED'
  amber-hover: '#D97706'
  amber-light: '#FEF3C7'
  amber-text: '#92400E'
  success: '#10B981'
  success-dark: '#059669'
  success-light: '#ECFDF5'
  error-dark: '#991B1B'
  error-light: '#FEF2F2'
  info: '#3B82F6'
  info-dark: '#1D4ED8'
  info-light: '#EFF6FF'
  text-main: '#111827'
  text-secondary: '#6B7280'
  text-tertiary: '#9CA3AF'
  bg-app: '#F3F4F6'
  bg-card: '#FFFFFF'
  bg-secondary: '#F9FAFB'
  border-default: '#E5E7EB'
typography:
  h1:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  h2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.3'
  h3:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.4'
  body:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: '1.5'
  secondary:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.4'
  label:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.2'
  micro:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.06em
  price:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '700'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter-desktop: 16px
  gutter-mobile: 10px
---

# Système de Design — TOKPa v2
# Marché Digital Bénin
 
> Ce document est la **source de vérité** pour toutes les interfaces TOKPa.
> Applique chaque règle à la lettre dans Stitch pour garantir la cohérence UI/UX
> sur les 18 pages de l'application (Client, Livreur, Manager, Administrateur).
 
---
 
## 1. Identité visuelle
 
**Nom de la marque :** TOKPa
**Slogan :** "Ton marché, ta façon"
**Direction artistique :** Vibrant & Local — chaleur du marché béninois, modernité numérique, accessibilité grand public.
 
**Variantes du logo acceptées :**
- Texte seul : `TOKPa` en Bold, couleur Primaire `#F97316`
- Texte bicolore : `TOK` en `#111827` + `Pa` en `#F97316`
- Pill inversé : fond `#F97316`, texte blanc, `border-radius: 12px`, padding `8px 18px`
- Dark pill : fond `#111827`, texte `#F97316`, `border-radius: 12px`
---
 
## 2. Couleurs
 
### 2.1 Couleur Primaire — Orange TOKPa
| Rôle | Hex | Usage |
|---|---|---|
| Primaire principale | `#F97316` | Boutons CTA, liens actifs, accents de marque |
| Primaire hover | `#EA580C` | Survol des boutons primaires |
| Primaire foncée | `#C2410C` | Texte sur fond orange clair |
| Primaire très foncée | `#7C2D12` | Texte sur fond très clair |
| Primaire claire | `#FED7AA` | Fonds secondaires, bordures douces |
| Primaire très claire | `#FFF7ED` | Fonds de sections, badges, highlights |
 
### 2.2 Accent Secondaire — Ambre (Négociation & Promotions)
| Rôle | Hex | Usage |
|---|---|---|
| Ambre principale | `#F59E0B` | Badges "Promo", module de négociation |
| Ambre hover | `#D97706` | Survol des éléments ambre |
| Ambre claire | `#FEF3C7` | Fond du module de négociation, bannières promo |
| Ambre texte | `#92400E` | Texte sur fond ambre clair |
 
### 2.3 Couleurs Sémantiques
| Rôle | Hex | Usage |
|---|---|---|
| Succès | `#10B981` | Badge "Disponible", statut "Livré", validations |
| Succès foncé | `#059669` | Texte succès, bouton Accepter |
| Succès claire | `#ECFDF5` | Fond badge Disponible |
| Succès bordure | `#6EE7B7` | Bordure badge Disponible |
| Erreur | `#EF4444` | Suppressions, erreurs formulaire |
| Erreur foncé | `#991B1B` | Texte erreur |
| Erreur claire | `#FEF2F2` | Fond badge Épuisé, bouton Refuser |
| Erreur bordure | `#FCA5A5` | Bordure erreur |
| Info | `#3B82F6` | Badge "Pack", informations neutres |
| Info foncé | `#1D4ED8` | Texte info |
| Info claire | `#EFF6FF` | Fond badge Pack |
| Alerte | `#F59E0B` | Avertissements, stock faible |
 
### 2.4 Neutres
| Rôle | Hex | Usage |
|---|---|---|
| Texte principal | `#111827` | Titres, texte important |
| Texte secondaire | `#6B7280` | Sous-titres, descriptions, placeholders |
| Texte tertiaire | `#9CA3AF` | Labels discrets, horodatages |
| Fond application | `#F3F4F6` | Background général de la page |
| Fond carte | `#FFFFFF` | Cartes, modales, containers |
| Fond secondaire | `#F9FAFB` | Zones de stat, inputs disabled |
| Bordure | `#E5E7EB` | Bordures par défaut |
| Bordure focus | `#F97316` | Bordure active sur inputs |
 
---
 
## 3. Typographie
 
**Police principale :** `Inter` (priorité) ou `Roboto` en fallback — sans-serif, propre, lisible sur mobile.
**Import Google Fonts :** `Inter:wght@400;500;600;700`
 
### Hiérarchie typographique
| Niveau | Taille | Poids | Couleur | Usage |
|---|---|---|---|---|
| H1 | 28px | 700 Bold | `#111827` | Titre principal de page |
| H2 | 20px | 600 SemiBold | `#111827` | Titres de section |
| H3 | 16px | 500 Medium | `#111827` | Sous-titres, titres carte |
| Corps | 15px | 400 Regular | `#111827` | Texte courant, descriptions |
| Secondaire | 13px | 400 Regular | `#6B7280` | Métadonnées, sous-titres discrets |
| Label | 13px | 500 Medium | `#6B7280` | Labels de formulaire |
| Micro | 11px | 500 Medium | `#9CA3AF` | Catégories en uppercase, horodatages |
| Prix | 16–20px | 700 Bold | `#F97316` | Affichage des prix en FCFA |
 
**Règle micro-texte :** Les labels de catégorie en micro-texte s'écrivent en `text-transform: uppercase` avec `letter-spacing: 0.06em`.
 
---
 
## 4. Composants d'interface
 
### 4.1 Boutons
Tous les boutons ont `border-radius: 10px`, `font-weight: 500`, `transition: opacity 0.15s, transform 0.1s`.
Au clic : `transform: scale(0.97)`.
 
#### Bouton Primaire (CTA principal)
```
fond       : #F97316
texte      : #FFFFFF
hover fond : #EA580C
padding    : 10px 20px (normal) | 6px 14px (petit)
icon+texte : gap 7px
```
Usage : "Ajouter au panier", "Commander", "Confirmer", "Envoyer l'offre"
 
#### Bouton Secondaire
```
fond      : #FFF7ED
texte     : #C2410C
bordure   : 1.5px solid #FED7AA
hover fond: #FED7AA
```
Usage : "Négocier le prix", "Modifier", actions secondaires
 
#### Bouton Ghost
```
fond      : transparent
texte     : #F97316
bordure   : 1.5px solid #F97316
hover fond: #FFF7ED
```
Usage : "Favoris", actions tertiaires
 
#### Bouton Succès
```
fond    : #ECFDF5
texte   : #065F46
bordure : 1.5px solid #6EE7B7
```
Usage : "Accepter", "Valider", "Marquer comme livré"
 
#### Bouton Danger
```
fond    : #FEF2F2
texte   : #991B1B
bordure : 1.5px solid #FCA5A5
```
Usage : "Refuser", "Supprimer", "Annuler la commande"
 
#### Bouton Désactivé
```
fond   : #D1D5DB
texte  : #9CA3AF
cursor : not-allowed
```
 
---
 
### 4.2 Champs de formulaire
 
#### Input standard
```
fond                 : #FFFFFF
bordure normale      : 1.5px solid #E5E7EB
border-radius        : 10px
padding              : 10px 14px
font-size            : 14px
état focus           : bordure #F97316 + box-shadow 0 0 0 3px rgba(249,115,22,0.15)
```
 
#### Label
```
display      : block
font-size    : 13px
font-weight  : 500
couleur      : #6B7280
margin-bottom: 6px
```
 
#### Select
Même style que l'input. Flèche native ou icône `chevron-down` positionnée à droite.
 
#### Input avec unité (prix FCFA)
Input standard + texte "FCFA" positionné en absolu à droite (`right: 14px`), couleur `#9CA3AF`, taille 12px.
 
#### Input avec icône action (mot de passe)
Input standard + icône `eye` / `eye-off` en absolu à droite, cliquable, couleur `#9CA3AF`.
 
---
 
### 4.3 Cartes (Cards)
 
#### Carte standard
```
fond          : #FFFFFF
bordure       : 0.5px solid #E5E7EB
border-radius : 14px
padding       : 16px 20px
```
 
#### Carte mise en avant (produit promo ou sélectionné)
```
bordure : 2px solid #F97316
```
Optionnel : bandeau supérieur `background: #FFF7ED`, `border-bottom: 1px solid #FED7AA`, hauteur 30px.
 
#### Carte produit — structure
```
1. Image placeholder (fond dégradé léger, hauteur 110px, border-radius 10px, icône centrée)
2. Ligne : Nom produit (H3) + Badge disponibilité
3. Ligne : Origine marché · Poids/Quantité (texte secondaire 12px)
4. Ligne : Prix en FCFA (bold orange) + Bouton "+" primaire petit
```
 
#### Carte statistique (dashboard)
```
fond          : #F9FAFB
border-radius : 10px
padding       : 14px 16px
label         : 12px, #6B7280
valeur        : 22px, font-weight 500, #111827
delta         : 12px, vert #059669 (hausse) ou rouge #DC2626 (baisse)
```
 
---
 
### 4.4 Badges
 
Tous les badges : `border-radius: 20px`, `padding: 3px 10px`, `font-size: 12px`, `font-weight: 500`.
Format avec pastille de couleur : `width: 7px; height: 7px; border-radius: 50%` avant le texte.
 
| Badge | Fond | Texte | Pastille | Usage |
|---|---|---|---|---|
| Disponible | `#ECFDF5` | `#065F46` | `#10B981` | Stock normal |
| Stock faible | `#FFF7ED` | `#C2410C` | `#F97316` | Stock bas |
| Épuisé | `#FEF2F2` | `#991B1B` | `#EF4444` | Rupture |
| Pack | `#EFF6FF` | `#1D4ED8` | — | Bundle de produits |
| Promo | `#FEF3C7` | `#92400E` | — | Promotion active |
| Nouveau | `#F9FAFB` | `#6B7280` | — | Produit récent |
| Négociation | `#FEF3C7` | `#92400E` | icône `coins` | Module budget |
 
---
 
### 4.5 Statuts de commande
 
Tous les statuts : `border-radius: 10px`, `padding: 10px 14px`, `font-size: 13px`, pastille ronde `8px`.
 
| Statut | Fond | Bordure | Texte | Pastille |
|---|---|---|---|---|
| En attente | `#FFFBEB` | `#FDE68A` | `#92400E` | `#F59E0B` |
| En préparation | `#EFF6FF` | `#BFDBFE` | `#1E40AF` | `#3B82F6` |
| En livraison | `#FFF7ED` | `#FED7AA` | `#9A3412` | `#F97316` |
| Livré | `#ECFDF5` | `#6EE7B7` | `#065F46` | `#10B981` |
| Annulé | `#FEF2F2` | `#FCA5A5` | `#991B1B` | `#EF4444` |
 
---
 
### 4.6 Navbar
 
```
fond          : #FFFFFF
bordure-bas   : 1px solid #F3F4F6
hauteur       : 52px
padding       : 0 16px (mobile) | 0 24px (desktop)
```
 
**Logo :** 18px Bold, couleur `#F97316`, `letter-spacing: -0.5px`, `margin-right: 24px`
 
**Items de navigation :**
```
padding       : 6px 12px
font-size     : 13px
couleur       : #6B7280
border-radius : 8px
état actif    : couleur #F97316, fond #FFF7ED, font-weight 500
```
 
**Zone actions (droite) :**
- Icône panier avec compteur : pastille `background: #F97316`, texte blanc, 16px, `-5px -7px` décalage
- Avatar utilisateur : cercle 32px, initiales, fond `#FFF7ED`, texte `#C2410C`
---
 
### 4.7 Avatars utilisateurs
 
```
border-radius : 50%
width / height : 38px (normal) | 32px (navbar) | 44px (profil)
font-size     : 13px (normal) | 12px (navbar) | 15px (profil)
font-weight   : 600
```
 
| Rôle | Fond | Texte |
|---|---|---|
| Client | `#FFF7ED` | `#C2410C` |
| Livreur | `#ECFDF5` | `#065F46` |
| Manager / Admin | `#EFF6FF` | `#1D4ED8` |
 
---
 
### 4.8 Module de négociation de prix
 
Composant unique à TOKPa. Toujours encadré avec `border-left: 3px solid #F59E0B`.
 
**Structure :**
```
1. En-tête : "Proposer un budget" (H3) + Badge "Négociation" (ambre)
2. Comparaison des prix :
   - Bloc gauche : "Prix vendeur" — fond #F3F4F6, prix en #111827
   - Icône échange : ti-arrows-exchange, couleur #F59E0B
   - Bloc droite : "Votre offre" — fond #FEF3C7, bordure #F59E0B, prix en #92400E
3. Actions : Bouton Succès "Envoyer l'offre" + Bouton Ghost "Annuler"
```
 
---
 
### 4.9 Chat (Client ↔ Livreur)
 
**En-tête de conversation :**
```
Avatar livreur + Nom + Rôle (14px, font-weight 500)
Indicateur en ligne : pastille 8px #10B981 + texte "En ligne" vert
Séparateur : border-bottom 0.5px solid #F3F4F6
```
 
**Bulles de message :**
```
max-width     : 78%
padding       : 9px 13px
font-size     : 13px
line-height   : 1.5
 
Message envoyé (moi) :
  fond          : #F97316
  texte         : #FFFFFF
  border-radius : 14px 14px 4px 14px
  align         : flex-end (droite)
 
Message reçu :
  fond          : #F9FAFB
  texte         : #111827
  border-radius : 14px 14px 14px 4px
  align         : flex-start (gauche)
```
 
---
 
### 4.10 Barre de progression
 
```
hauteur       : 6px
fond piste    : #F3F4F6
border-radius : 3px
fond remplissage : #F97316
```
 
---
 
## 5. Agencement (Layout)
 
### 5.1 Grilles
Utiliser CSS Grid ou Flexbox exclusivement.
 
| Contexte | Colonnes | Gap |
|---|---|---|
| Catalogue produits desktop | 3 à 4 colonnes | 16px |
| Catalogue produits mobile | 2 colonnes | 10px |
| Statistiques dashboard | 4 colonnes desktop, 2 mobile | 12px |
| Formulaires | 2 colonnes desktop, 1 mobile | 16px |
| Contenu principal | 1 colonne, max-width 1200px centré | — |
 
### 5.2 Espacements standardisés
| Token | Valeur | Usage |
|---|---|---|
| xs | 4px | Séparateur interne, gap label/info |
| sm | 8px | Gap icône/texte, padding petit |
| md | 16px | Entre éléments de même niveau |
| lg | 24px | Padding carte, entre sections |
| xl | 40px | Entre blocs majeurs de page |
 
### 5.3 Breakpoints
| Breakpoint | Largeur | Comportement |
|---|---|---|
| Mobile | < 640px | 1 colonne, navbar collapsed (hamburger) |
| Tablet | 640px – 1024px | 2 colonnes, navbar partielle |
| Desktop | > 1024px | 3–4 colonnes, navbar complète |
 
### 5.4 Fond de page
```
background-color : #F3F4F6
padding          : 24px (desktop) | 16px (mobile)
```
 
---
 
## 6. Iconographie
 
**Bibliothèque :** Tabler Icons (outline uniquement — jamais `-filled`).
**Taille :** 20px inline, 24px décoratif max.
 
| Contexte | Icône Tabler |
|---|---|
| Panier | `ti-shopping-cart` |
| Produit/plante | `ti-plant-2` |
| Poisson | `ti-fish` |
| Catégorie/bundle | `ti-basket` |
| Localisation | `ti-map-pin` |
| Livraison/moto | `ti-motorbike` |
| Négociation | `ti-arrows-exchange` |
| Pièces/monnaie | `ti-coins` |
| Tendance haussière | `ti-trending-up` |
| Tendance baissière | `ti-trending-down` |
| Envoi | `ti-send` |
| Statut/horloge | `ti-clock` |
| Tableau de bord | `ti-layout-dashboard` |
| Utilisateurs | `ti-users` |
| Paramètres | `ti-settings` |
| GPS/tracking | `ti-current-location` |
| Téléphone | `ti-phone` |
| Chat | `ti-message-circle` |
| Favoris | `ti-heart` |
| Valider | `ti-check` |
| Refuser/fermer | `ti-x` |
| Ajouter | `ti-plus` |
| Modifier | `ti-edit` |
| Supprimer | `ti-trash` |
| Œil (password) | `ti-eye` / `ti-eye-off` |
| Menu mobile | `ti-menu-2` |
| Notification | `ti-bell` |
| Catalogue admin | `ti-category` |
| Zones | `ti-map` |
| Audit/logs | `ti-clipboard-list` |
